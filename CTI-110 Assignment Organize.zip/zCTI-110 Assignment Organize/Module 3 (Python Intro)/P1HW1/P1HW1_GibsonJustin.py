user_num = int(input('Enter integer:\n'))
squared = user_num * user_num
cubed = user_num * user_num * user_num

print("You entered:", user_num)
print(user_num, "squared is", squared)
print("And", user_num, "cubed is", cubed, "!!")
user_num2 = int(input('Enter another integer:\n'))
sum = user_num + user_num2
product = user_num * user_num2
print(user_num, "+", user_num2, "is", sum)
print(user_num, "*", user_num2, "is", product)