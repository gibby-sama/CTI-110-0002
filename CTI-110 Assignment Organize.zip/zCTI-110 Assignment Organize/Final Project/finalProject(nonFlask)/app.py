from flask import Flask, render_template, request
from views import views

app = Flask(__name__)
app.register_blueprint(views, url_prefix="/")

def calculate_calories(u_gender, u_age, u_ft, u_in, u_weight, u_activity, u_goal):
    ## Convert weight from pounds to kg(*0.454)
    o_weight = u_weight * 0.454

    ## Convert height to inches (*12) then to cm (*2.54)
    o_height_c = (u_ft * 12) + u_in
    o_height = o_height_c * 2.54


    ## Use Harris-Bennedict Equation to find BMR (Basal Metabolic Rate)
    #  AKA how many calories your body burns in a day
    ## Men BMR = (10 * weight in kg) + (6.25 * height in cm) – (5 * age in years) + 5
    ## Women BMR = (10 * weight in kg) + (6.25 * height in cm) – (5 * age in years) – 161

    m_BMR = (10*o_weight)+(6.25*o_height)-(5*u_age)+(5)
    f_BMR = (10*o_weight)+(6.25*o_height)-(5*u_age)+(-161)

    if u_gender == 'Male':
        o_BMR = m_BMR
    elif u_gender == 'Female':
        o_BMR = f_BMR

    ## Create an activity modifier to multiply into the BMR (variable o_BMR)
    # 1.2 sedentary, little or no exercise     (1)
    # 1.375 light exercise 1-3 days per week   (2)
    # 1.55 moderate exercise 3-5 days per week (3)
    # 1.7 hard exercise 6-7 days per week      (4)
    # 1.9 very hard exercise every day         (5)
    #                                           ^ Activity modifier identifiers (for elif statements)

    if u_activity == '1':
        o_activity = 1.2
    elif u_activity == '2':
        o_activity = 1.375
    elif u_activity == '3':
        o_activity = 1.55
    elif u_activity == '4':
        o_activity = 1.7
    elif u_activity == '5':
        o_activity = 1.9
        
    m_calories = o_BMR*o_activity

    ## Define calorie ranges for goals of gaining & losing
    # 200-500 calories in excess or deficit of maintenance calories is a healthy goal
    o_gain1 = (m_calories)+(200)
    o_gain2 = (m_calories)+(500)
    o_lose1 = (m_calories)+(-200)
    o_lose2 = (m_calories)+(-500)
        
    if u_goal == '1':
        o_calories = int(m_calories)
    elif u_goal == '2':
        o_calories = f'{int(o_lose2)} to {int(o_lose1)}'
    elif u_goal == '3':
        o_calories = f'{int(o_gain1)} to {int(o_gain2)}'    

    return o_BMR, m_calories, o_calories

@app.route('/calculate', methods=['POST'])
def calculate():
    u_gender = request.form['u_gender']
    u_age = int(request.form['u_age'])
    u_ft = int(request.form['u_ft'])
    u_in = int(request.form['u_in'])
    u_weight = int(request.form['u_weight'])
    u_activity = request.form['u_activity']
    u_goal = request.form['u_goal']

    o_BMR, m_calories, o_calories = calculate_calories(u_gender, u_age, u_ft, u_in, u_weight, u_activity, u_goal)

    return render_template('results.html', o_BMR=o_BMR, m_calories=m_calories, o_calories=o_calories)

def bmr_calc():
    return render_template('bmr_calc.html')

if __name__ == '__main__':
    app.run(debug=True, port=6969)
