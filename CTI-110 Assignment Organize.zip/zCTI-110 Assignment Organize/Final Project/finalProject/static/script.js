// script.js

document.addEventListener("DOMContentLoaded", function () {
    // Get references to the hamburger icon and dropdown content
    var hamburgerIcon = document.querySelector(".hamburger");
    var dropdownContent = document.querySelector(".dropdown-content");

    // Show/hide dropdown on click
    hamburgerIcon.addEventListener("click", function () {
        // Toggle the visibility of the dropdown content
        dropdownContent.style.display = (dropdownContent.style.display === "flex") ? "none" : "flex";
    });

    // Close dropdown if clicked outside
    document.addEventListener("click", function (event) {
        if (!event.target.matches('.hamburger') && !event.target.matches('.dropdown-content')) {
            dropdownContent.style.display = "none";
        }
    });
});