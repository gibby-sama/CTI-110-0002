from flask import Blueprint, render_template

#Python Flask doesn't need a specific file path
#'templates' is pre-defined as the source for the .html file directory
views = Blueprint(__name__, "views")

@views.route("/")
def welcome():
    return render_template("welcome.html")

@views.route("/bmr_calc")
def bmr_calc():
    return render_template("bmr_calc.html")

@views.route("/how_it_works")
def how_it_works():
    return render_template("how_it_works.html")

@views.route("/results")
def results():
    return render_template("results.html")

@views.route("/basic_exercises")
def basic_exercises():
    return render_template("basic_exercises.html")
