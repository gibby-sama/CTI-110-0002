mpg = float(input())
dpg = float(input())

gas1 = 20 / mpg * dpg 
gas2 = 75 / mpg * dpg
gas3 = 500 / mpg * dpg
print(f'{gas1:.2f} {gas2:.2f} {gas3:.2f}')